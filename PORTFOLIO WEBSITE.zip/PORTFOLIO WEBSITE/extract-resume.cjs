const fs = require('fs');
const pdf = require('pdf-parse');

pdf(fs.readFileSync('Resume.pdf'))
  .then((document) => process.stdout.write(document.text))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
