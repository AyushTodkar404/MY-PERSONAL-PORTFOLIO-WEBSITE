const profileImage = document.getElementById("profile-image");
const profileUpload = document.getElementById("profile-upload");
const storedProfilePhoto = localStorage.getItem("profilePhoto");

if (storedProfilePhoto) profileImage.src = storedProfilePhoto;

profileUpload.addEventListener("change", () => {
  const [file] = profileUpload.files;
  if (!file) return;

  const reader = new FileReader();
  reader.addEventListener("load", () => {
    profileImage.src = reader.result;
    localStorage.setItem("profilePhoto", reader.result);
  });
  reader.readAsDataURL(file);
});
